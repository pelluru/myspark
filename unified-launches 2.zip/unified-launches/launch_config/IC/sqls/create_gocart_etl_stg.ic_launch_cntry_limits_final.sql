drop table  gocart_etl_stg.ic_launch_cntry_limits_with_agust_31st_rows
create table gocart_etl_stg.ic_launch_cntry_limits_with_agust_31st_rows as SELECT a.* FROM gocart_etl_stg.ic_launch_cntry_limits a join gocart.launched_icid_dates b on a.icid = b.icid and a.app_key = b.appkey
drop table gocart_etl_stg.ic_launch_cntry_limits_final
create table gocart_etl_stg.ic_launch_cntry_limits_final as select * from gocart_etl_stg.ic_launch_cntry_limits except select * from gocart_etl_stg.ic_launch_cntry_limits_with_agust_31st_rows