from launch_pipelines.utils.data_files_root_paths import APPLICATION_CONFIG_ROOT_PATH
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session
from launch_pipelines.utils.table_utils import materialize_dataframes

import logging

def  get_launch_config(spark_session):
    return spark_session.read.csv(header=True,
                                        path=APPLICATION_CONFIG_ROOT_PATH+"/launch_config/load_launch_config.csv")


def createTableOrTempTable(result_data_frame,spark_session,table_name):
            logging.info("********************** before creating  table : %s",table_name )
            materialize_dataframes(spark_session,result_data_frame,table_name)
            logging.info("********************** after creating  table : %s",table_name)

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    spark_session = get_hive_spark_session()
    launch_config_df = get_launch_config(spark_session)
    createTableOrTempTable(launch_config_df,spark_session,"gocart_bi_sandbox.ic_campaign_lookup")
