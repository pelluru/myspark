import logging

from launch_pipelines import launch_config
from launch_pipelines.launch_config.launch_config import LaunchConfig
from launch_pipelines.utils import hive_spark_session_util, data_files_root_paths

logging.basicConfig(
        format='%(asctime)s %(levelname)-8s %(message)s',
        level=logging.INFO,
        datefmt='%Y-%m-%d %H:%M:%S')
"""
can execute any spark sql's
"""
class SingleSQLExecutor:

    def execute(self, sql_file_name):

          logging.getLogger().setLevel(logging.INFO)

          # launch config
          spark_session = hive_spark_session_util.get_hive_spark_session()

          with open(sql_file_name) as sqls:
              sql_querys = sqls.readlines()
              for sql_query in sql_querys:
                result_df = spark_session.sql(sql_query)
                logging.info("****************** sql execute succesfully: %s",sql_query)
                result_df.show()

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    single_sql_executor = SingleSQLExecutor()
    single_sql_executor.execute("/user/gocuser/unified-launches/unified-launches/launch_config/UAT/IC/sqls/gocart_etl_stg.launched_suid_dates_buck_pp.sql")