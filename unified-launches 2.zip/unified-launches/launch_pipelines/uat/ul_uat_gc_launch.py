import logging

from launch_pipelines.uat.single_sql_executor import SingleSQLExecutor
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session
from launch_pipelines.utils.table_utils import materialize_dataframes
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType, LongType, BooleanType, \
    TimestampType

if __name__ == "__main__":

    launched_suid_dates_schema = StructType([ \
            StructField("suid", StringType(), True), \
            StructField("launch_id", StringType(), True), \
            StructField("launch_description", StringType(), True), \
            StructField("launch_date", StringType(), True), \
            StructField("launch_phase", IntegerType(), True), \
            StructField("previous_phase", IntegerType(), True), \
            StructField("launch_country", IntegerType(), True), \
            StructField("cohort_id", StringType(), True), \
            StructField("is_full_experiences", IntegerType(), True), \
            StructField("is_test", IntegerType(), True), \
            StructField("cx_version", IntegerType(), True), \
            StructField("test_launch", IntegerType(), True), \
            StructField("launch_type", StringType(), True), \
            StructField("external_campaign", StringType(), True), \
            StructField("arnold_flag", IntegerType(), True), \
            StructField("ooc_flag", IntegerType(), True), \
            StructField("detarget_flag", IntegerType(), True), \
            StructField("products_launched", ArrayType(StringType(), True), True), \
            StructField("is_paid", StringType(), True), \
            StructField("gen_product_count", LongType(), True), \
            StructField("have_member_guid", IntegerType(), True), \
            StructField("os", StringType(), True), \
            StructField("hacked_used_flag", IntegerType(), True), \
            StructField("sibling_flag", IntegerType(), True), \
            StructField("frequency_hacked", StringType(), True), \
            StructField("photoshop_count", LongType(), True), \
            StructField("segment_adobe", StringType(), True), \
            StructField("usage_type", StringType(), True), \
            StructField("operational_country", IntegerType(), True), \
            StructField("migration_history", StringType(), True), \
            StructField("targeting_process", StringType(), True), \
            StructField("is_latest_launch", StringType(), True) \
        ])


    spark_session = get_hive_spark_session()
    single_sql_executor = SingleSQLExecutor()


    # load launch csv file
    uat_data_frame_df = spark_session.read.csv("hdfs://nameservice1/user/gocuser/unified_launches/launch_config/UAT/IC/current_launch/gocart_etl_stg.launched_icid_dates_uat_ic_temp.csv", header=True,schema=launched_icid_dates_schema)

    uat_data_frame_df.show()

    uat_data_frame_df.printSchema()

    uat_data_frame_df.createOrReplaceTempView("uat_data_frame")

    temp_table_name_df = spark_session.sql("select temp_table_name  from uat_data_frame limit 1")

    temp_table_name = temp_table_name_df.first()['temp_table_name']

    logging.info("temp_table_name %s", temp_table_name)

    # total launch suid
    total_count_icids_df =   spark_session.sql("select  count(*) as total_count_icids from uat_data_frame")

    total_count_icids = total_count_icids_df.first()['total_count_icids']

    logging.info("total_count_icids %d",total_count_icids)

    # get existing records count
    total_count_existing_icids_df = spark_session.sql("select  count(*) as total_count_existing_icids  from uat_data_frame  where existing_id_flag = 'TRUE'")

    total_count_existing_icids_df.show()

    total_count_existing_icids = total_count_existing_icids_df.first()['total_count_existing_icids']

    logging.info("total_count_existing_icids %d", total_count_existing_icids)

    drop_columns  = ("existing_id_flag", "temp_table_name")
    uat_data_frame_dropped_col_df = uat_data_frame_df.drop(*drop_columns)

    logging.info("********************** before creating  table : %s", temp_table_name)
    materialize_dataframes(spark_session, uat_data_frame_dropped_col_df,temp_table_name)
    logging.info("********************** after creating  table : %s", temp_table_name)



    logging.info("********************** before creating  table : launched_icid_dates_uat_ic_final")
    single_sql_executor.execute("/user/gocuser/unified-launches/unified-launches/launch_config/UAT/IC/sqls/gocart_etl_stg.launched_icid_dates_uat_ic_final.sql")
    logging.info("********************** after creating  table : launched_icid_dates_uat_ic_final")


    logging.info("********* updating  ic_target total_count_icids %d:",total_count_icids)
    logging.info("********* updating  ic_target total_count_existing_icids %d:", total_count_existing_icids)

    # update ic_target table if new icid in the UAT
    if total_count_existing_icids != total_count_icids:

        logging.info("********* inside updating  ic_target total_count_icid ")

        launched_ic_targets_schema = StructType([ \
          StructField("temp_table_name", StringType(), True), \
          StructField("icid", StringType(), True), \
          StructField("os_user_id", StringType(), True), \
          StructField("app_key", StringType(), True), \
          StructField("cohort_id", StringType(), True), \
          StructField("country_code", IntegerType(), True), \
          StructField("country_name", StringType(), True), \
          StructField("exploit_id", IntegerType(), True), \
          StructField("binary_modified", BooleanType(), True), \
          StructField("consequence_category", StringType(), True), \
          StructField("notif_url", StringType(), True), \
          StructField("notif_height", IntegerType(), True), \
          StructField("notif_width", IntegerType(), True), \
          StructField("notif_position", StringType(), True), \
          StructField("product_phase", IntegerType(), True), \
          StructField("app_terminate", BooleanType(), True), \
          StructField("app_termination_timer", IntegerType(), True), \
          StructField("notif_close_timer", IntegerType(), True), \
          StructField("deleted", BooleanType(), True), \
          StructField("last_update_time",  TimestampType(), True), \
          StructField("external_campaign", StringType(), True) \
                ])

        # load  uat launch csv file
        ic_targets_df = spark_session.read.csv("hdfs://nameservice1/user/gocuser/unified_launches/launch_config/UAT/IC/current_launch/gocart_etl_stg.ic_target_temp_uat_ic_pp.csv", header=True,schema=launched_ic_targets_schema)

        ic_targets_df.show()

        ic_targets_df.printSchema()

        ic_targets_temp_table_name = ic_targets_df.first()['temp_table_name']

        logging.info("ic_targets_temp_table_name %s", ic_targets_temp_table_name)

        drop_ic_target_columns = ("temp_table_name")
        ic_targets_dropped_col_df = ic_targets_df.drop(*drop_ic_target_columns)

        logging.info("********************** before creating  table : %s", ic_targets_temp_table_name)
        materialize_dataframes(spark_session, ic_targets_dropped_col_df, ic_targets_temp_table_name)
        logging.info("********************** after creating  table : %s", ic_targets_temp_table_name)

        logging.info("********************** before creating  table : gocart_etl_stg.ic_target_uat_ic_final")
        single_sql_executor.execute("/user/gocuser/unified-launches/unified-launches/launch_config/UAT/IC/sqls/gocart_etl_stg.ic_target_uat_ic_final.sql")
        logging.info("********************** after creating  table : gocart_etl_stg.ic_target_uat_ic_final")

