import logging

from launch_pipelines.uat.ul_uat_sql_executor import SingleSQLExecutor
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, ArrayType, LongType

if __name__ == "__main__":

    launched_suid_dates_schema = StructType([ \
            StructField("suid", StringType(), True),\
            StructField("launch_id", StringType(), True),\
            StructField("launch_description", StringType(), True),\
            StructField("launch_date", StringType(), True),\
            StructField("launch_phase",  IntegerType(),True),\
            StructField("previous_phase",  IntegerType(),True),\
            StructField("launch_country",   IntegerType(),True),\
            StructField("cohort_id", StringType(), True),\
            StructField("is_full_experiences",   IntegerType(),True),\
            StructField("is_test",   IntegerType(),True),\
            StructField("cx_version",   IntegerType(),True),\
            StructField("test_launch",    IntegerType(),True),\
            StructField("launch_type",StringType(), True),\
            StructField("external_campaign",StringType(), True),\
            StructField("arnold_flag",   IntegerType(),True),\
            StructField("ooc_flag",    IntegerType(),True),\
            StructField("detarget_flag",    IntegerType(),True),\
            StructField("products_launched",  ArrayType(StringType(),True),True),\
            StructField("is_paid", StringType(), True),\
            StructField("gen_product_count", LongType(),True), \
            StructField("have_member_guid",    IntegerType(),True),\
            StructField("os",  StringType(), True),\
            StructField("hacked_used_flag",     IntegerType(),True),\
            StructField("sibling_flag",     IntegerType(),True),\
            StructField("frequency_hacked", StringType(), True),\
            StructField("photoshop_count",    LongType(), True),\
            StructField("segment_adobe",  StringType(), True),\
            StructField("usage_type",  StringType(), True),\
            StructField("operational_country",   IntegerType(),True),\
            StructField("migration_history", StringType(), True),\
            StructField("targeting_process",  StringType(), True),\
            StructField("is_latest_launch",   StringType(), True)\
            ])

    spark_session = get_hive_spark_session()

    single_sql_executor = SingleSQLExecutor()



    launched_suid_dates_buck_pp_df = spark_session.sql( "select  * from gocart_etl_stg.launched_suid_dates_buck_pp")

    launched_suid_dates_buck_pp_df.show()
    logging.info("******************* launched_suid_dates_buck_pp_df  schema ")
    launched_suid_dates_buck_pp_df.printSchema()



    # create a buck table
    single_sql_executor.execute(
        "/user/gocuser/unified-launches/unified-launches/launch_config/UAT/GC/sqls/gocart_etl_stg.launched_suid_dates_buck_pp.sql")

    launch_schema = launched_suid_dates_buck_pp_df.schema;
    # load launch csv file
    uat_data_frame = spark_session.read.csv("hdfs://nameservice1/user/gocuser/unified_launches/launch_config/UAT/GC/current_launch/gocart_etl_stg.uat_gc_launch_launched_suid_dates.csv",header=True,schema=launch_schema)

    uat_data_frame.createOrReplaceTempView("uat_data_frame")

    buck_table_name_df = spark_session.sql("select buck_table_name  from uat_data_frame limit 1")
    buck_table_name = buck_table_name_df.first()['buck_table_name']
    logging.info("buck_table_name %s", buck_table_name)

    # total launch suid
    total_count_suids_df =   spark_session.sql("select  count(*) as total_count_suids from uat_data_frame")

    total_count_suids = total_count_suids_df.first()['total_count_suids']

    logging.info("total_count_suids %d",total_count_suids)

    # get existing records count
    total_count_existing_suids_df = spark_session.sql("select  count(*) as total_count_existing_suids  from uat_data_frame  where existing_suid_flag = 'TRUE'")

    total_count_existing_suids_df.show()

    total_count_existing_suids = total_count_existing_suids_df.first()['total_count_existing_suids']

    logging.info("total_count_existing_suids %d", total_count_existing_suids)

    #uat_launch_suids_df2 = spark_session.read.csv("hdfs://nameservice1/user/gocuser/unified_launches/launch_config/UAT/GC/current_launch/gocart_etl_stg.uat_gc_launch_launched_suid_dates.csv",header=True)

    columns_needs_to_drop  = ['existing_suid_flag','buck_table_name']
    uat_data_frame2 =  uat_data_frame.drop(*columns_needs_to_drop)

    uat_data_frame2.show()
    logging.info("******************* uat_data_frame2 schema ")
    uat_data_frame2.printSchema()

    launched_suid_dates_buck_pp_df_final = launched_suid_dates_buck_pp_df.union(uat_data_frame2)

    launched_suid_dates_buck_pp_df_final.show()
    logging.info("******************* launched_suid_dates_buck_pp_df_final schema ")
    launched_suid_dates_buck_pp_df_final.printSchema()
