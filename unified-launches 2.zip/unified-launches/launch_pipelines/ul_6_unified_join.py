import logging
import traceback

# Import date class from datetime module
from datetime import date

from launch_pipelines.utils import hive_spark_session_util
from launch_pipelines.utils.table_utils import materialize_dataframes
from pyspark.sql.functions import lit, col, when, current_timestamp

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

logging.basicConfig(
        format='%(asctime)s %(levelname)-8s %(message)s',
        level=logging.INFO,
        datefmt='%Y-%m-%d %H:%M:%S')
"""
abstracts what  ever a generic join needed like
left table , right table
"""
class UnifiedJoin:

    def __init__(self,
                 config_record,
                 config_row_id,
                 join_type,
                 left_table,
                 right_table,
                 left_side_columns,
                 right_side_columns,
                 left_select_columns,
                 right_select_columns,
                 additional_default_columns,
                 joined_result_table_name,
                 temp_table_result_flag,
                 sql_filter_conditions,
                 dedupe_flag,
                 dedupe_columns
                 ) :
        self._config_record = config_record
        self._config_row_id = config_row_id
        self._join_type = join_type
        self._left_table=left_table
        self._right_table = right_table
        self._left_side_columns = left_side_columns
        self._right_side_columns = right_side_columns
        self._left_select_columns = left_select_columns
        self._right_select_columns = right_select_columns
        self._additional_default_columns = additional_default_columns
        self._joined_result_table_name =  joined_result_table_name
        self._temp_table_result_flag = temp_table_result_flag
        self._sql_filter_conditions = sql_filter_conditions
        self._dedupe_flag = dedupe_flag
        self._dedupe_columns = dedupe_columns
    @property
    def config_record(self):
        return self._config_record

    @property
    def config_row_id(self):
        return self._config_row_id

    @property
    def join_type(self):
        return self._join_type

    @property
    def left_table(self):
        return self._left_table

    @property
    def right_table(self):
        return self._right_table

    def set_left_table(self, left_table):
        self._left_table= left_table

    @property
    def left_side_columns(self):
        return self._left_side_columns
    @property
    def right_side_columns(self):
        return self._right_side_columns

    @property
    def left_select_columns(self):
        return self._left_select_columns

    @property
    def right_select_columns(self):
        return self._right_select_columns
    @property
    def additional_default_columns(self):
        return self.additional_default_columns

    @property
    def sql_filter_conditions(self):
        return self._sql_filter_conditions

    @property
    def dedupe_flag(self):
        return self._dedupe_flag


    def join(self):
          logging.getLogger().setLevel(logging.INFO)

          logging.info(self)

          spark_session = hive_spark_session_util.get_hive_spark_session()

          left_cols = list(map(lambda column_name: 'l.'+column_name  , self._left_side_columns))
          right_cols = list(map(lambda column_name: 'r.'+column_name , self._right_side_columns))

          logging.info("left_cols:"+str(left_cols))
          logging.info("right_cols:" + str(right_cols))

          left_select_columns = list(map(lambda column_name: 'l.' + column_name, self._left_select_columns))
          right_select_columns = list(map(lambda column_name: 'r.' + column_name, self._right_select_columns))

          logging.info("left_select_columns:%s",left_select_columns)
          logging.info("right_select_columns:%s", right_select_columns)

          # construct dynamic join conditions
          join_column_list = [col(l) == col(r) for (l, r) in zip(left_cols, right_cols)]
          logging.info("join_column_list: %s" ,join_column_list)

          try:

            left_table_df = self.create_df(self._left_table,spark_session)
            logging.info("left_table:%s row count:%d",self._left_table,left_table_df.count())

            # add additional default columns
            logging.info("self._additional_default_columns: %s",len(self._additional_default_columns))


            right_table_df = self.create_df(self._right_table,spark_session)
            logging.info("right_table:%s row count:%d", self._right_table, right_table_df.count())

            # join two tables
            joined_df =  left_table_df.alias('l').join(right_table_df.alias("r"),join_column_list,self._join_type).select(left_select_columns+right_select_columns)
            logging.info("******************** joining clause begins")
            logging.info("%s.alias('l').join(%s.alias("r"),%s,%s).select(%s+%s)",self._left_table,self._right_table,str(join_column_list),self._join_type,str(left_select_columns),str(right_select_columns))
            logging.info("******************* joining clause ends")

            logging.info("count after join :%s config row_id:%s", joined_df.count(), self._config_row_id);

            # add default additional columns only in the first joined intermediate table
            if self.config_row_id == "1":
                logging.info("self._additional_default_columns: %d",self._additional_default_columns)
                for additional_col in self._additional_default_columns:
                    logging.info("adding default column:%s",additional_col.additional_column_name)
                    joined_df = joined_df.withColumn(additional_col.additional_column_name,lit(additional_col.default_value))

                joined_df = joined_df.withColumn("frequency_hacked",
                                                              when(joined_df.frequency.isNull(),
                                                                   "LOW").otherwise(joined_df.frequency))

                joined_df = joined_df.withColumn("app_key", joined_df.appkey)
                joined_df = joined_df.withColumn("country_code", joined_df.country)
                joined_df = joined_df.withColumn("country_name", joined_df.country_iso_2)
                joined_df = joined_df.withColumn("binary_modified",lit(False))
                joined_df = joined_df.withColumn("deleted", lit(False))

                todays_date_time = date.today()

                todays_date_string = todays_date_time.strftime('%Y-%m-%d')
                logging.info("******************* todays_date_string:%s",todays_date_string)

                joined_df = joined_df.withColumn("launch_date", lit(todays_date_string))
                joined_df = joined_df.withColumn("client_reference_id",
                                                                   joined_df.clientreferenceid)
                joined_df = joined_df.withColumn("last_update_time", current_timestamp())
                logging.info("************ First join additional columns ")
            else:
                joined_df = joined_df
                logging.info("************ First join No additional columns ")

            joined_df.show()

            if self._dedupe_flag == "True":
                joined_df = joined_df.dropDuplicates(self._dedupe_columns)
                logging.info("count after dedupe :%s config row_id:%s", joined_df.count(), self._config_row_id);

            logging.debug("Join for config row_id %s explain: %s",self._config_row_id, joined_df._jdf.queryExecution().toString())
          except Exception as e:
             logging.error(traceback.format_exc())
             logging.error("left_table_df.alias('l').join(right_table_df.alias("r"),join_column_list,self._join_type).select(left_select_columns+right_select_columns)")
             raise Exception("Error occured in joining:"+str(self))

          # apply configured filters after the join
          final_df = self.apply_filter_conditions(joined_df)

          # create Temp table or managed Table
          self.createTableOrTempTable(final_df,spark_session)

          return final_df

    # create Dataframe from the table
    def create_df(self,table_name,spark_session):
         return spark_session.sql("select * from " + table_name)

    # save the dataframe to the table
    def createTableOrTempTable(self, result_data_frame,spark_session):

        logging.info("****** entered createTableOrTempTable:"+self._joined_result_table_name)

        result_data_frame.show()

        # if self._joined_result_table_name == "gocart_bi_sandbox.pp_inventory_inventory_usage":
        #     result_data_frame2 = result_data_frame.withColumn("frequency_hacked", when(result_data_frame.frequency.isNull(), "LOW").otherwise(result_data_frame.frequency))

            # result_data_frame2 = result_data_frame2.withColumn("app_key", result_data_frame.appkey)
            # result_data_frame2 = result_data_frame2.withColumn("country_code", result_data_frame.country)
            # result_data_frame2 = result_data_frame2.withColumn("country_name", result_data_frame.country_iso_2)
            # result_data_frame2 = result_data_frame2.withColumn("launch_date", lit('2022-09-21'))
            # result_data_frame2 = result_data_frame2.withColumn("client_reference_id", result_data_frame.clientreferenceid)
            # result_data_frame2 = result_data_frame2.withColumn("last_update_time", current_timestamp())

            # additional columns
            # result_data_frame2 = result_data_frame2.withColumn("os_user_id", lit('*'))
            # result_data_frame2 = result_data_frame2.withColumn("binary_modified", lit(False))
            # result_data_frame2 = result_data_frame2.withColumn("gen_product_count", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("have_member_guid", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("hacked_used_flag", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("sibling_flag", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("segment_adobe", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("operational_country", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("migration_history", lit(' '))
            # result_data_frame2 = result_data_frame2.withColumn("phase", lit(0))
            # result_data_frame2 = result_data_frame2.withColumn("product_phase", lit(0))
            # result_data_frame2 = result_data_frame2.withColumn("consequence_category", lit('NONE'))
            # result_data_frame2 = result_data_frame2.withColumn("deleted", lit(False))
            # result_data_frame2 = result_data_frame2.withColumn("detarget_flag", lit(0))

            #logging.info("after updating column null to 'LOW")
        # else:
        #     result_data_frame2 = result_data_frame

        if self._temp_table_result_flag == 'True':
            logging.info("*********************** before creating temp table : %s",self._joined_result_table_name)
            result_data_frame.registerTempTable(self._joined_result_table_name)
            logging.info("*********************** after creating temp table : %s", self._joined_result_table_name)

        else:
            logging.info("********************** before creating  table : %s", self._joined_result_table_name)
            materialize_dataframes(spark_session,result_data_frame,self._joined_result_table_name)
            logging.info("********************** after creating  table : %s", self._joined_result_table_name)


    # apply configured filter conditions after the join
    def apply_filter_conditions(self, joined_df):
        # applies filter/where conditions
        logging.info("apply_filter_conditions: %s", self._sql_filter_conditions)
        logging.info("Number of filter_conditions: %d", len(self._sql_filter_conditions))

        for filter_condition in self._sql_filter_conditions:
            # work around not to interpret comma in CSV file
            filter_condition = filter_condition.replace("$$",",")
            logging.info("********* before applying filter_condition: %s", filter_condition)
            logging.info("before filter count: %d", joined_df.count())
            joined_df = joined_df.filter(filter_condition)
            logging.info("after filter count: %d", joined_df.count())
            logging.debug("********* filter condition: %s explain: %s", filter_condition, joined_df._jdf.queryExecution().toString())
            logging.info("********* after applying filter_condition: %s", filter_condition)
        return joined_df

    def __str__(self):
          return  'UnifiedJoin('+'\n'+ \
                  'config_record=' + str(self._config_record ) + '\n'+ \
                  ',config_row_id=' +  \
                  self._config_row_id  + '\n' + \
                  ',join_type=' +  \
                  self._join_type + '\n' + \
                  ',left_table=' + \
                  self._left_table + '\n' + \
                  ',right_table=' + \
                  self._right_table + '\n' + \
                  ',left_side_columns=' + \
                  str(self._left_side_columns) + '\n' +\
                  ',right_side_columns=' + \
                  str(self._right_side_columns) + '\n'\
                  ',left_select_columns=' + \
                  str(self._left_select_columns) + '\n' \
                  ',right_select_columns=' + \
                  str(self._right_select_columns) + '\n' \
                  ',joined_result_table_name=' + \
                  str(self._joined_result_table_name) + '\n' \
                  ',temp_table_result_flag=' + \
                  str(self._temp_table_result_flag) + '\n' \
                  ',sql_filter_conditions=' + \
                  str(self._sql_filter_conditions) + '\n'


class AdditionalColumn:

    def __init__(self, launch_type,additional_column_name ,column_type,default_value) :
        self._launch_type = launch_type
        self._additional_column_name  = additional_column_name
        self._column_type = column_type
        self._default_value = default_value

    @property
    def launch_type(self):
        return self._launch_type

    @property
    def additional_column_name(self):
        return self._additional_column_name

    @property
    def column_type(self):
        return self._column_type

    @property
    def default_value(self):
        return self._default_value
