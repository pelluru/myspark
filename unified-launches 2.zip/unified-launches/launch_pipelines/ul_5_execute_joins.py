# Python
import logging

from launch_pipelines.ul_4_create_dataframes_from_hive_strategy import CreateDataFramesFromHIVEStrategy

logging.basicConfig(
        format='%(asctime)s %(levelname)-8s %(message)s',
        level=logging.INFO,
        datefmt='%Y-%m-%d %H:%M:%S')

# unified launches


def  execute_joins(launch_type,command_type):

        logging.getLogger().setLevel("INFO")

        logging.info("entered create_filtered_inventory()")

        unified_joins  = CreateDataFramesFromHIVEStrategy().createDataFrames(launch_type, command_type)

        logging.info("********************* number of unified joins:"+str(len(unified_joins)))

        for u_join in unified_joins:

            filtered_df = u_join.join()

            # return filtered_df
        return filtered_df