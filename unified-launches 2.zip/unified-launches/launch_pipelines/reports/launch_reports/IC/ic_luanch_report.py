import logging
import os
from datetime import datetime

from jinja2 import Environment, FileSystemLoader
from launch_pipelines.utils import hive_spark_session_util

#TARGETTED_MACHINES_SQL = "select country_name as country, app_key , count(*) as machine_count from  gocart_etl_stg.ic_launch_cntry_limits_final  group by country_name,app_key order by country_name"
TARGETTED_MACHINES_SQL = "select country_name as country, app_key , count(*) as machine_count from  gocart_etl_stg.ic_launch_cntry_limits_final  group by country_name,app_key order by country_name"
TARGETTED_MACHINES_COUNT_SQL = "select count(*) as targetted_machines_count from gocart_etl_stg.ic_launch_cntry_limits_final"
TARGETTED_MACHINES_BY_PRODUCT = "select app_key , count (*) as machine_count  from gocart_etl_stg.ic_launch_cntry_limits_final  group by app_key order by machine_count desc"

TEMPLATE_PATH="/user/gocuser/unified-launches/unified-launches/launch_pipelines/reports/launch_reports/IC"
GENERATED_REPORT_PATH = "/user/gocuser/unified-launches/unified-launches/launch_reports/"

class GenerateLaunchReport:
    def generate_launchReport(self):
        ic_launch_report = getICLaunchReport()
        # 2. Create a template Environment
        env = Environment(loader=FileSystemLoader(TEMPLATE_PATH+'/jinja_templates/', encoding='utf8'))

        # 3. Load the template from the Environment
        targetted_machines_template = env.get_template('ic_luanch_report_template.html')

        # get data required for report
        context = {
            "ic_launch_report": ic_launch_report.target_machines,
            "launch_date": ic_launch_report.launch_date,
            "total_number_of_machines": ic_launch_report.total_number_of_machines,
            "targetted_machines_by_product": ic_launch_report.targetted_machines_by_product
        }

        # create launch HTML report
        with open(GENERATED_REPORT_PATH+"ic_launch_report.html", mode="w") as targetted_machines:
            targetted_machines.write(targetted_machines_template.render(context))


class ICLaunchReport:
    def __init__(self,
                 target_machines,
                 launch_date,
                 total_number_of_machines,
                 targetted_machines_by_product
                 ):
        self._target_machines = target_machines
        self._launch_date = launch_date
        self._total_number_of_machines = total_number_of_machines
        self._targetted_machines_by_product = targetted_machines_by_product

    @property
    def target_machines(self):
        return self._target_machines

    @property
    def launch_date(self):
        return self._launch_date

    @property
    def total_number_of_machines(self):
        return self._total_number_of_machines

    @property
    def targetted_machines_by_product(self):
        return self._targetted_machines_by_product



class TargettedMachine:
    def __init__(self,country,application_type,machine_count):
        self._country = country
        self._application_type = application_type
        self._machine_count = machine_count

    @property
    def country(self):
        return self._country

    @property
    def application_type(self):
        return self._application_type

    @property
    def machine_count(self):
        return self._machine_count


def getICLaunchReport():

    spark_session = hive_spark_session_util.get_hive_spark_session()

    targetted_machines_df = spark_session.sql(TARGETTED_MACHINES_SQL)

    targetted_machines_df.show()

    logging.info("******************* just before writing csv file")
    # write excel report
    repart = targetted_machines_df.repartition(1)
    repart.write.csv("/user/gocuser/unified-launches/unified-launches/launch_reports/ic_launch_report_csv/",header=True,mode="overwrite")
    logging.info("******************* just after  writing csv file")

    targetted_machines_rows = targetted_machines_df.collect()
    targetted_machines = []

    for targetted_machines_row in targetted_machines_rows:
        targetted_machines_row_dict = targetted_machines_row.asDict()
        targetted_machine = TargettedMachine(
            country=targetted_machines_row_dict['country'],
            application_type=targetted_machines_row_dict['app_key'],
            machine_count=targetted_machines_row_dict['machine_count']
        )
        targetted_machines.append(targetted_machine)

    print(targetted_machines)

    targetted_machines_count_df = spark_session.sql(TARGETTED_MACHINES_COUNT_SQL)

    targetted_machines_count_df.show()

    targetted_machines_count_rows = targetted_machines_count_df.collect()

    total_machines_count = 0
    for targetted_machines_count_row in targetted_machines_count_rows:
        targetted_machines_count_dict = targetted_machines_count_row.asDict()
        print(targetted_machines_count_dict)
        total_machines_count = targetted_machines_count_dict['targetted_machines_count']

    launch_date = datetime.today().strftime('%m-%d-%Y')

    ic_launch_report =  ICLaunchReport(targetted_machines,launch_date,total_machines_count,getTargettedMachinesByProductReport())

    return  ic_launch_report

def getTargettedMachinesByProductReport():

    spark_session = hive_spark_session_util.get_hive_spark_session()

    targetted_machines_df = spark_session.sql(TARGETTED_MACHINES_BY_PRODUCT)

    targetted_machines_rows = targetted_machines_df.collect()
    targetted_machines = []

    for targetted_machines_row in targetted_machines_rows:
        targetted_machines_row_dict = targetted_machines_row.asDict()
        targetted_machine = TargettedMachine(
            country="None",
            application_type=targetted_machines_row_dict['app_key'],
            machine_count=targetted_machines_row_dict['machine_count']
        )
        targetted_machines.append(targetted_machine)

    return  targetted_machines
