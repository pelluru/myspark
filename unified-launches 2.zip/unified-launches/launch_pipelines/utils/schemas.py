import pyspark.sql.functions as F


class Schema():
    # Schemas for writing tables
    STG = "gocart"
    PROD = "gocart_bi_sandbox"
    PREFIX = "shalu_"
    DATE = '2021-06-01'
    LOW_RANGE = '2021-12-04'
    HIGH_RANGE = '2022-03-04'  # for testing

    # Schemas lookup table references
    REF_STG = "gocart_etl_stg."
    REF_PROD = "gocart"
    REF_SANDBOX = "gocart_bi_sandbox"

    # temporarily use prod tables here; these should eventually be created in-pipeline
    SCENARIO_GID_QFM_GID = "gocart_etl_stg.scenario_gid_qfm_gid"
    SCENARIO_CAMPAIGN_QFM_CAMPAIGN = "gocart_etl_stg.scenario_campaign_qfm_campaign"

    WEB_TABLE_EXTRACT_ORDERS = "gocart.gc_web_table_extract_orders"

    BT_EVENTS = "gocart.bt_events_vact"

    # filtered versions of original tables from preprocess.sql
    WEB_TABLE_EXTRACT_TRIALS = "gocart_bi_sandbox.gc_web_table_extract_trials_conv"
    WEB_TABLE_EXTRACT_CAMPAIGNS = "gocart_bi_sandbox.gc_web_table_extract_campaigns_conv"
    FACT_USER_ACTIVITY = "gocart_bi_sandbox.fact_user_activity_conv"
    CCMUSG_FACT_DOWNLOAD_INFO = "gocart_bi_sandbox.ccmusg_fact_download_info_conv"

    FP_COUNTRY = "gocart_bi_sandbox.fp_country"
    FP_DIM_DATE = "gocart_etl_stg.fp_dim_date"
    AT_ADOBE_ALL_PRODUCTS = "sourcedata.at_adobe_all_products"
    NOTIFIED_SUID_GID_DIST = "gocart_etl_stg.notified_suid_gid_dist"
    NOTIFIED_SUID_GID_CNVRSN = "gocart_etl_stg.notified_suid_gid_cnvrsn"
    NOTIFIED_MGUID_CNVRSN = "gocart_etl_stg.notified_mguid_cnvrsn"
    WEB_TABLE_EXTRACT_GID = "gocart.gc_web_table_extract_gid"
    IMS_SIGNUP_MGUID = "gocart_etl_stg.gocart_ims_signup_mguid"
    NOTIFIED_MGUID_PROD_LAUNCH_CNVRSN = "gocart_etl_stg.notified_mguid_prod_launch_cnvrsn"
    MCC_ORDER_NOTIFIED_EXT = "gocart_etl_stg.mcc_order_notified_ext"
    TARGETED_MGUID_CNVRSN = "gocart_etl_stg.targeted_mguid_cnvrsn"
    SUID_MGUID = "gocart_etl_stg.suid_mguid"
    LAUNCHED_SUID_DATES = "gocart.launched_suid_dates"
    CCM_PIVOT_REFERENCE = "gocart_etl_stg.ccm_pivot_reference"
    CCM_PIVOT_4_ALL = "ccm_subscrpn.vw_ccm_pivot4_all"
    FACT_UQFM_QFM_PAID = "ocf_mf.fact_uqfm_qfm_paid"
    GUID_MODEL = "ems.guid_model"
    HANA_CCMUSAGE_SCD_MEMBER = "warehouse.hana_ccmusage_scd_member"
    NOTIFIED_SUID_MGUID = "gocart_etl_stg.notified_suid_mguid"
    TARGETED_SUID_MGUID = "gocart_etl_stg.targeted_suid_mguid"
    SUID_MGUID_PROD_LAUNCH = "gocart_etl_stg.suid_mguid_prod_launch"
    DIM_BAOZUN_ORDER2SUBSCRIPTION_BASIC = "gocart_etl_stg.dim_baozun_order2subscription_basic"
    DIM_SUBSCRIPTION = "ccm_subscrpn.dim_subscription"
    DMBO_GID_EVENT = "gocart_etl_stg.dmbo_gid_event"
    DIM_COUNTRY = "gocart.dim_country"
    WAREHOUSE_COUNTRY = "warehouse.country"
    AFC_CAMPAIGNS = "gocart_bi_sandbox.afc_campaigns"

    # PTT
    PTT_ACTIVATION = "gocart_etl_stg.ptt_activation"
    SERIAL_NUMBER_AUDIT = "gocart.serial_number_audit"
    DIM_DATE = "gocart.dim_date"
    CONVERSIONS_SCENARIOS_BUILD = "gocart_etl_stg.conversions_scenarios_build"
    DIM_SEAT = "ccm_jem.dim_seat"
    CO_GEO_TEST_FINAL_END = "gocart_bi_sandbox.co_geo_test_final_end"
    CONVERSION_REPORTING_PIVOT_FINAL_DASHBOARD = "gocart.conversion_reporting_pivot_final_dashboard"