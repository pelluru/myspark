import sys


class QueryManager:

    def __init__(self, spark):
        self.spark = spark

    def load_tables(self, table_list):
        """Best for speed efficiency, but faces memory issues"""
        for name, query in table_list:
            print("Loading table {}".format(name))
            self.register_table(name, query)

    def load_api_tables(self, table_list):
        for name, dataframe in table_list:
            print("Loading table {}".format(name))
            self.register_api_table(name, dataframe)

    def persist_dataframes(self, query):
        df = self.spark.sql(query)
        return df.cache()

    def register_table(self, name, query):
        """Creating a view"""
        table = self.spark.sql(query)
        table.createOrReplaceTempView(name)

    def register_api_table(self, table_name, dataframe):
        dataframe.createOrReplaceTempView(table_name)

    # def write_hive_compatible(self, table_name, temp_table):
    #     drop_query = "DROP TABLE IF EXISTS {}".format(table_name)
    #     self.spark.sql(drop_query)
    #     create_query = """create table {} as select * from {}""".format(table_name, temp_table)
    #     self.spark.sql(create_query)
    #     sys.stdout.write('wrote {} to hive\n'.format(table_name))

    def write_hive_compatible_table(self, df, cols, table_name, num_partition):
        drop_query = "DROP TABLE IF EXISTS {}".format(table_name)
        self.spark.sql(drop_query)
        create_query = "create table if not exists {} (".format(table_name) + cols + ") stored as parquet TBLPROPERTIES('PARQUET.COMPRESS'='SNAPPY')"
        self.spark.sql(create_query)
        self.spark.catalog.refreshTable(table_name)
        df.localCheckpoint().coalesce(num_partition)\
            .write \
            .option("compression", "snappy")\
            .mode("overwrite") \
            .insertInto(table_name, overwrite=True)
        sys.stdout.write('wrote {} to hive\n'.format(table_name))


    def write_hive_compatible_table_1(self, df, cols, table_name, num_partition):
        drop_query = "DROP TABLE IF EXISTS {}".format(table_name)
        self.spark.sql(drop_query)
        create_query = "create table if not exists {} (".format(table_name) + cols + ") stored as parquet TBLPROPERTIES('PARQUET.COMPRESS'='SNAPPY')"
        self.spark.sql(create_query)
        self.spark.catalog.refreshTable(table_name)
        df.coalesce(num_partition)\
            .write \
            .option("compression", "snappy")\
            .mode("overwrite") \
            .insertInto(table_name, overwrite=True)
        sys.stdout.write('wrote {} to hive\n'.format(table_name))

    def write_to_hive_with_schema(self, dataframe, table_name, schema):
        drop_query = "DROP TABLE IF EXISTS {}".format(table_name)
        self.spark.sql(drop_query)
        dataframe.write.mode('overwrite')\
            .schema(schema)\
            .format('parquet').\
            saveAsTable(table_name)
        sys.stdout.write('wrote {} to hive\n'.format(table_name))

    @staticmethod
    def write_to_hive(dataframe, table_name):
        dataframe.write.mode('overwrite').format('parquet').saveAsTable(
            table_name)
        sys.stdout.write('wrote {} to hive\n'.format(table_name))