APPLICATION_CONFIG_ROOT_PATH = "/user/gocuser/unified_launches"
LAUNCH_CONFIG_ROOT_PATH = "/user/gocuser/unified_launches"
