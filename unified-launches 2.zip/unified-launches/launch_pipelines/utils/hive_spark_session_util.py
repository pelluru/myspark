# Create SparkSession from builder with hive support

# python
import logging

# pySpark
from os.path import abspath

import pyspark
from pyspark.sql import SparkSession

def get_hive_spark_session():
    logging.info("inside get_hive_spark_session")
    # Spark Settings
    config = pyspark.SparkConf().setAll([
        ('spark.scheduler.mode', 'FAIR'),
        ('spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation', 'true'),
        ('spark.sql.warehouse.dir', '/user/hive/warehouse'),
        ('spark.sql.shuffle.partitions', '200'),  # JR: 200; can use unravel to hint at more/less partitions
        ('spark.sql.crossJoin.enabled', 'true'),
        ('spark.dynamicAllocation.enabled', 'false'),
        ('spark.driver.maxResultSize', '8g')
    ])

    warehouse_location = abspath('../spark-warehouse')
    logging.info("spark-warehouse:"+warehouse_location)

    spark = SparkSession \
        .builder \
        .appName("Unified launch") \
        .config("spark.sql.warehouse.dir", warehouse_location) \
        .config("spark.sql.hive.convertMetastoreOrc", "false") \
        .config("spark.sql.crossJoin.enabled", "true") \
        .enableHiveSupport() \
        .getOrCreate()

    sc = spark.sparkContext
    sc.setLogLevel("ERROR")

    return spark

