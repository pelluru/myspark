# Create SparkSession from builder

from pyspark.sql import SparkSession

def get_spark__session():
    spark_session = SparkSession.builder.master("local[1]") \
        .appName('unified launches with source CSV') \
        .getOrCreate()
    return spark_session


if __name__ == "__main__":
    print(get_spark__session())