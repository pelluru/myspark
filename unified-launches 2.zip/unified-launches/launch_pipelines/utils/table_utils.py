import time
import sys

import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as F

from launch_pipelines.utils.query_manager import QueryManager

#
# def append_schema_test(table_name):
#     return '.'.join([schema.STG, table_name])
#
#
# def append_schema(table_name):
#     return '.'.join([schema.STG, table_name])
#
#

def get_spark_session():
    start = time.time()
    # Spark Settings
    config = pyspark.SparkConf().setAll([
        ('spark.scheduler.mode', 'FAIR'),
        ('spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation', 'true'),
        ('spark.sql.warehouse.dir', '/user/hive/warehouse'),
        ('spark.sql.shuffle.partitions', '200'),  # JR: 200; can use unravel to hint at more/less partitions
        ('spark.sql.crossJoin.enabled', 'true'),
        ('spark.dynamicAllocation.enabled', 'false'),
        ('spark.driver.maxResultSize', '8g')
    ])

    spark = SparkSession.builder \
        .config(conf=config) \
        .appName('cohort_mgmt') \
        .enableHiveSupport() \
        .getOrCreate()

    get_total_run_time(start, 'GET SPARK SESSION')

    return spark


def materialize_dataframes(spark, df, table_name, num_partition=1):
    """Writing to disk"""
    start = time.time()
    create_hive_table(spark, df, table_name, num_partition)
    get_total_run_time(start, 'MATERIALIZE TABLE {}'.format(table_name))

def materialize_dataframes_no_cp(spark, df, table_name, num_partition=1):
    """Writing to disk"""
    start = time.time()
    create_hive_table_1(spark, df, table_name, num_partition)
    get_total_run_time(start, 'MATERIALIZE TABLE {}'.format(table_name))


# def materialize_stg_tables(spark, table):
#     """Writing to disk"""
#     start = time.time()
#     query_manager = QueryManager(spark)
#     dataframe = spark.table(table)
#     spark.catalog.refreshTable(table)
#     query_manager.write_to_hive(dataframe,
#                                 '{}.{}{}'.format(
#                                     schema.STG,
#                                     schema.PREFIX,
#                                     table))
#     get_total_run_time(start, 'MATERIALIZE TABLE {}'.format(table))


def persist_df(spark, query):
    query_manager = QueryManager(spark)
    return query_manager.persist_dataframes(query)


# def register_and_materialize(spark, table):
#     """Saving intermediate results into a table.  Use when facing memory or column ambiguity issues.  Slower option, but
#     helps with memory issues"""
#     query_manager = QueryManager(spark)
#     name, query = table
#     query_manager.register_table(name, query)
#     materialize_stg_tables(spark, table[0])


def get_total_run_time(start, process):
    """ Given a start time, calculate the total run time and log a message"""
    end = time.time()
    total_time = round(end - start, 2)
    sys.stdout.write('\n--- END OF {} ---\n'.format(process))
    sys.stdout.write('Total running time of {} seconds\n'.format(total_time))
    sys.stdout.write(
        'Total running time of {} minutes\n'.format(total_time / 60))
    sys.stdout.write('-' * 79)


# def drop_tables(spark):
#     sys.stdout.write("DROPPING TABLES\n")
#     query = query_tables_with_prefix()
#     tables = spark.sql(query).collect()
#
#     for row in tables:
#         query = query_drop_table(row)
#         sys.stdout.write("{}\n".format(query))
#         spark.sql(query)
#     sys.stdout.write("DROPPED {} tables\n".format(len(tables)))
#

def query_drop_table(row):
    full_name = '.'.join([row.database, row.tableName])
    return "DROP TABLE IF EXISTS {}".format(full_name)


# def query_tables_with_prefix():
#     return "SHOW TABLES FROM {} LIKE '{}*'".format(schema.PROD, schema.PREFIX)


def cast_date_to_timestamp(df):
    for col_name, d_type in df.dtypes:
        if d_type == 'date':
            df = df.withColumn(col_name, F.to_timestamp(F.col(col_name), 'yyyy-MM-dd'))
    return df


def get_columns_as_string(df):
    new_schema = []
    for col in df.dtypes:
        new_schema.append((col[0] + " " + col[1]))
    cols = ','.join(str(item) for item in new_schema)
    return cols


def create_hive_table(spark, df, table_name, num_partition):
    df = cast_date_to_timestamp(df)
    cols = get_columns_as_string(df)
    manager = QueryManager(spark)
    manager.write_hive_compatible_table(df, cols, table_name, num_partition)


def create_hive_table_1(spark, df, table_name, num_partition):
    df = cast_date_to_timestamp(df)
    cols = get_columns_as_string(df)
    manager = QueryManager(spark)
    manager.write_hive_compatible_table_1(df, cols, table_name, num_partition)


def cast_null_cols_to_str(df):
    my_schema = list(df.schema)
    null_cols = []

    for st in my_schema:
        if str(st.dataType) == 'NullType':
            null_cols.append(st)

    for ncol in null_cols:
        mycol_name = str(ncol.name)
        df = df.withColumn(mycol_name, df[mycol_name].cast('string'))

    return df