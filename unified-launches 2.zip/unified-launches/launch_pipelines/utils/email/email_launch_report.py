import smtplib, ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart



class EmailLaunchReports:

      def sendLaunchReports(self):
            # config = {
            #     "recipients": "ppelluru@adobe.com",
            #     "frm_email_id": "rlyhdp@adobe.com"
            #        }

            config = {
                "recipients": "lat27668@adobe.com,ssachdeva@adobe.com,gsrivastava@adobe.com,syedak@adobe.com,venkyi@adobe.com,ahitan@adobe.com,colson@adobe.com,gc-programmatic-launc-aaaagu5uwj7dkbs2ctmwlm72ja@adobe.org.slack.com",
                "frm_email_id": "rlyhdp@adobe.com"
                   }

            sender_email = config["frm_email_id"]
            receiver_email = config["recipients"]

            message = MIMEMultipart("alternative")
            message["Subject"] = "IC Launch Report"
            message["From"] = sender_email
            message["To"] = receiver_email


            text = """ IC Launch Report attached"""

            html_attachment_path = "/user/gocuser/unified-launches/unified-launches/launch_reports/ic_launch_report.html"
            excel_attachment_path= "/user/gocuser/unified-launches/unified-launches/launch_reports/ic_launch_report.csv"

            html = open(html_attachment_path)



            # Turn these into plain/html MIMEText objects
            part1 = MIMEText(text, "plain")
            part2 = MIMEText(html.read(), "html")

            # read excel Report
            with open(excel_attachment_path, "rb") as attachment:
                part3 = MIMEBase("application", "octet-stream")
                part3.set_payload(attachment.read())
            encoders.encode_base64(part3)

            ic_launch_report_excel_file_name = "ic_launch_report.csv"
            part3.add_header(
                "Content-Disposition",
                "attachment", filename=ic_launch_report_excel_file_name
            )

            # Add HTML/plain-text parts to MIMEMultipart message
            # The email client will try to render the last part first
            message.attach(part1)
            message.attach(part2)
            message.attach(part3)

            try:
                smtpObj = smtplib.SMTP('localhost')
                smtpObj.sendmail(sender_email, receiver_email.split(","), message.as_string())
                print("Successfully sent Launch Report email")
            except smtplib.SMTPException:
                print("Error: unable to send Launch Report email")