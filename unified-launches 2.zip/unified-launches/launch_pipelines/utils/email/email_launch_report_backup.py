""" An email client, to send message with the launch report """

import smtplib

from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

SENDER_EMAIL = "rlyhdp@adobe.com"
RECEIVERS = ['ppelluru@adobe.com']

def send_launch_report():
    """ Send an email with the launch report  as attachment"""
    subject = "IC Launch Report"

    sender_email = SENDER_EMAIL
    receiver_emails = RECEIVERS

    # Create a multipart message and set headers
    message = MIMEMultipart('alternative')
    message['From'] = sender_email
    message['To'] = RECEIVERS
    message['Subject'] = subject

    # Add body to email
    message.attach(MIMEText("IC launch Report", "html"))

    attachment_path = "/user/gocuser/unified-launches/unified-launches/launch_pipelines/utils/email/email_launch_report.html"

    if attachment_path:
        message = add_attachment(message, attachment_path)
    text = message.as_string()

    server = smtplib.SMTP('localhost')
    server.sendmail(sender_email, receiver_emails, text)
    server.quit()
    return True

def add_attachment(message, attachment_path):
    """ Add the attachment to the message """
    with open(attachment_path, 'rb') as attachment:
        # Add file as application/octet-stream
        # Email client can usually download this automatically as attachment
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())
    # Encode file in ASCII characters
    encoders.encode_base64(part)
    # Add header as key/value pair attachment part
    part.add_header(
        "Content-Disposition",
        "attachment; filename={}".format(attachment_path)
    )
    # Add attachment to message and convert to string
    message.attach(part)
    return message


if __name__ == "__main__":
    send_launch_report()

