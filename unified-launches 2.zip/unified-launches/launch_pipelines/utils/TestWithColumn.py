# import logging
#
# from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session
# from pyspark.sql import functions as F
# from pyspark.sql.functions import col, when
#
# TABLE_NAME = "gocart_bi_sandbox.pp_inventory_inventory_usage"
#
# if TABLE_NAME == "gocart_bi_sandbox.pp_inventory_inventory_usage":
#
#     df = sc.parallelize([("1323323232", None), ("546345345", 'HIGH'), ("6778567454", "MEDIUM"),("4234234423", None)]).toDF(["icicid", "frequency"])
#
#     df = df.withColumn("frequency", when(df.frequency.isNull(), "LOW").otherwise(df.frequency))
#     df.show()
