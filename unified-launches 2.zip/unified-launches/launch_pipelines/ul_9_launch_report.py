from launch_pipelines.application_config.application_config import application_config
from launch_pipelines.ul_3_launch_command import FindInventoryRceiver, Invoker, TargetRceiver, FindInventoryCommand, \
    TargeCommand, CountryLimitRceiver, CountryLimitCommand, SqlExcecutorRceiver, SqlExecutorCommand, \
    GenerateLaunchReportRceiver, GenerateLaunchReportCommand
from launch_pipelines.utils import LAUNCH_TYPES
from launch_pipelines.utils.email.email_launch_report import EmailLaunchReports
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session

if __name__ == "__main__":

    spark_session = get_hive_spark_session()
    app_config = application_config(spark_session, LAUNCH_TYPES.IC)

    # client that is responsible for
    # executing  all commands
    command_invoker = Invoker()

    # generate a report
    generate_launch_report_receiver= GenerateLaunchReportRceiver(LAUNCH_TYPES.IC);
    generate_launch_report_command = GenerateLaunchReportCommand(generate_launch_report_receiver)
    command_invoker.store_command(generate_launch_report_command)

    # execute commands in the order added
    command_invoker.execute_commands()

    # send launch report email
    emailLaunchReports = EmailLaunchReports()
    emailLaunchReports.sendLaunchReports()
