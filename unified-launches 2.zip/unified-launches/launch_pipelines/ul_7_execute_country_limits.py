import logging

from launch_pipelines.application_config.application_config import application_config
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session
from launch_pipelines.utils.table_utils import materialize_dataframes

import sys
reload(sys)
sys.setdefaultencoding('utf-8')

class ExecuteCountryLimits:

    LIMIT_QUERY_BY_APP_KEY = "SELECT * FROM {table_name} WHERE COUNTRY = {country_numeric_code}  AND  upper(app_key) = '{app_key}'  limit "
    LIMIT_QUERY  = "SELECT * FROM {table_name} WHERE COUNTRY = {country_numeric_code}  limit "


    def executeCountyLimits(self,table_name,launch_type):
            spark_session= get_hive_spark_session()
            app_config = application_config(spark_session,launch_type)
            country_limit_df = app_config.get_country_limit_config()
            country_limit_rows = country_limit_df.collect()
            logging.info("country_limit_df count:%d",country_limit_df.count())

            country_limit_list = []
            for country_limit_row in country_limit_rows:
                country_limit_row_dict = country_limit_row.asDict()
                country_limit = CountyLimit(
                    launch_type=country_limit_row_dict['launch_type'],
                    country_numeric_code=country_limit_row_dict['country_numeric_code'],
                    app_key = country_limit_row_dict['app_key'],
                    limit=country_limit_row_dict['inventory_limit'],
                )
                country_limit_list.append(country_limit)

            select_inventory = "select * from {spark_temp_table_name} limit 1"
            select_inventory = select_inventory.format(spark_temp_table_name=table_name)


            country_limited_df = spark_session.sql(select_inventory)

            logging.info("country_limited_df count: %d",country_limited_df.count())

            for country_limit in country_limit_list:
                logging.info("country limiting:{country} '{app_key}' {limit} begins:"+country_limit.country_numeric_code, country_limit.app_key,country_limit.limit)

                query = ""

                if country_limit.app_key =="None":
                    query= self.LIMIT_QUERY.format(table_name=table_name,
                                               country_numeric_code=country_limit.country_numeric_code) + country_limit.limit
                else:
                    query = self.LIMIT_QUERY_BY_APP_KEY.format(table_name=table_name,
                                                    country_numeric_code=country_limit.country_numeric_code,
                                                    app_key=country_limit.app_key) + country_limit.limit

                logging.info("query:%s",query)
                intermediate_df =  spark_session.sql(query)
                logging.info("intermediate_df count: %d", intermediate_df.count())
                logging.info("country limiting:{country}  {app_key} {limit} ends "+country_limit.country_numeric_code, country_limit.app_key,country_limit.limit)

                country_limited_df = country_limited_df.union(intermediate_df)
                logging.info("country_limited_df count: %d", country_limited_df.count())


            createTableOrTempTable(country_limited_df,spark_session,"gocart_etl_stg.ic_launch_cntry_limits")
            return country_limited_df

    # save the dataframe to the table
def createTableOrTempTable(result_data_frame,spark_session,table_name):
            logging.info("********************** before creating  table : %s",table_name )
            deduped_df = result_data_frame.dropDuplicates(['icid','app_key'])
            materialize_dataframes(spark_session,deduped_df,table_name)
            logging.info("********************** after creating  table : %s",table_name)

class CountyLimit:
    def __init__(self, launch_type,country_numeric_code, app_key,limit):
        self.launch_type = launch_type
        self.country_numeric_code = country_numeric_code
        self.app_key = app_key
        self.limit= limit


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    executeCountrylimits = ExecuteCountryLimits()
    executeCountrylimits.executeCountyLimits("gocart_etl_stg.ic_launch")