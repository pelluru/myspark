"""
This class loads all application config
@TODO make this as Singleton
"""
from launch_pipelines.utils.data_files_root_paths import APPLICATION_CONFIG_ROOT_PATH


class application_config():
    def __init__(self,spark_session ,launch_type):
        self._spark_session = spark_session
        self._launch_type = launch_type
        self._launch_type_path = "/application_config/"+launch_type

    def get_join_config(self):
         return self._spark_session.read.csv(header=True,
                                                path=APPLICATION_CONFIG_ROOT_PATH+self._launch_type_path+"/launch_join_app_config.csv")

    def get_addional_columns_config(self):
        return self._spark_session.read.csv(header=True,
                                                path=APPLICATION_CONFIG_ROOT_PATH+self._launch_type_path+"/launch_addional_default_columns_app_config.csv")

    def get_country_limit_config(self):
        return self._spark_session.read.csv(header=True,
                                                path=APPLICATION_CONFIG_ROOT_PATH+self._launch_type_path+"/country_limit_config.csv")

    def get_global_config(self):
        return self._spark_session.read.csv(header=True,
                                                path=APPLICATION_CONFIG_ROOT_PATH+self._launch_type_path+"/global_config.csv")
