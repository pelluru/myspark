"""
This class loads all application config
@TODO make this as Singleton
"""
from launch_pipelines.utils.data_files_root_paths import APPLICATION_CONFIG_ROOT_PATH


class uat_application_config():
    def __init__(self,spark_session ):
        self._spark_session = spark_session
        self._launch_type_path = "/application_config/"+"UAT"

    def get_uat_suid_config(self):
         return self._spark_session.read.csv(header=True,
                                                path=APPLICATION_CONFIG_ROOT_PATH+self._launch_type_path+"/uat_suid_config.csv")

    def get_gocart_etl_stg_notif_url_attrs_stg_config(self):
        return self._spark_session.read.csv(header=True,
                                                path=APPLICATION_CONFIG_ROOT_PATH+self._launch_type_path+"/gocart_etl_stg.notif_url_attrs_stg_config.csv")

