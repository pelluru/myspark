import logging

from launch_pipelines import launch_config
from launch_pipelines.launch_config.launch_config import LaunchConfig
from launch_pipelines.utils import hive_spark_session_util, data_files_root_paths

logging.basicConfig(
        format='%(asctime)s %(levelname)-8s %(message)s',
        level=logging.INFO,
        datefmt='%Y-%m-%d %H:%M:%S')
"""
can execute any spark sql's
"""
class SQLExecutor:

    def execute(self,launch_type):

          sql_path = data_files_root_paths.LAUNCH_CONFIG_ROOT_PATH+"/launch_config/"+launch_type+"/sqls/"
          logging.getLogger().setLevel(logging.INFO)

          # launch config
          spark_session = hive_spark_session_util.get_hive_spark_session()

          # get sql config
          launch_config = LaunchConfig(spark_session,launch_type)
          sql_config_df = launch_config.get_sql_config()

          sql_config_rows = sql_config_df.collect()
          logging.info("sql_config_rows count:%d", sql_config_df.count())

          for sql_config_row in sql_config_rows:
              sql_config_row_dict = sql_config_row.asDict()
              logging.info("sql index: %s sql to be executed: %s",sql_config_row_dict['sql_index'],sql_config_row_dict['sql_file_name'])

              with open("/user/gocuser/unified-launches/unified-launches/launch_config/IC/sqls/"+sql_config_row_dict['sql_file_name']) as sqls:
                  sql_querys = sqls.readlines()
                  for sql_query in sql_querys:
                    result_df = spark_session.sql(sql_query)
                    logging.info("****************** sql execute succesfully: %s",sql_query)
                    result_df.show()

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    sql_executor = SQLExecutor()
    sql_executor.execute("IC")