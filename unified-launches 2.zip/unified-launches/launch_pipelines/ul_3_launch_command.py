"""
Encapsulate a request as an object, thereby letting you parameterize
clients with different requests, queue or log requests, and support
undoable operations.
"""

import abc

# compatible with Python 2 *and* 3:
import logging

from launch_pipelines.reports.launch_reports.IC.ic_luanch_report import GenerateLaunchReport
from launch_pipelines.ul_7_execute_country_limits import ExecuteCountryLimits
from launch_pipelines.ul_5_execute_joins import execute_joins
from launch_pipelines.ul_8_sql_executor import SQLExecutor

ABC = abc.ABCMeta('ABC', (object,), {'__slots__': ()})


class Invoker:
    """
    Ask the command to carry out the request.
    """

    def __init__(self):
        self._commands = []

    def store_command(self, command):
        self._commands.append(command)

    def execute_commands(self):
        for command in self._commands:
            command.execute()

class FindInventoryRceiver:
    def __init__(self,launch_type,command_type):
       self._launch_type = launch_type
       self._command_type = command_type
    """
    Know how to perform the operations associated with carrying out a
    request. Any class may serve as a Receiver.
    """

    def action(self):
       final_df =  execute_joins(self._launch_type,self._command_type)

class TargetRceiver:
    def __init__(self,launch_type,command_type):
       self._launch_type = launch_type
       self._command_type = command_type
    """
    Know how to perform the operations associated with carrying out a
    request. Any class may serve as a Receiver.
    """

    def action(self):
        final_df = execute_joins(self._launch_type,self._command_type)

class CountryLimitRceiver:
    def __init__(self,table_name,launch_type):
       self._table_name = table_name
       self._launch_type = launch_type

    """
    Know how to perform the operations associated with carrying out a
    request. Any class may serve as a Receiver.
    """

    def action(self):
        execute_country_limits= ExecuteCountryLimits();
        final_df = execute_country_limits.executeCountyLimits(self._table_name,self._launch_type)

class SqlExcecutorRceiver:
    def __init__(self,launch_type):
       self._launch_type = launch_type

    """
    Know how to perform the operations associated with carrying out a
    request. Any class may serve as a Receiver.
    """

    def action(self):
        logging.getLogger().setLevel(logging.INFO)
        sql_executor = SQLExecutor()
        sql_executor.execute(self._launch_type)

class  GenerateLaunchReportRceiver:
    def __init__(self,launch_type):
       self._launch_type = launch_type

    """
    Know how to perform the operations associated with carrying out a
    request. Any class may serve as a Receiver.
    """

    def action(self):
        logging.getLogger().setLevel(logging.INFO)
        generate_launch_report = GenerateLaunchReport()
        generate_launch_report.generate_launchReport()

class LaunchCommand(ABC):
    """
    Declare an interface for executing an operation.
    """

    def __init__(self, receiver):
        self._receiver = receiver

    @abc.abstractmethod
    def execute(self):
        pass

class FindInventoryCommand(LaunchCommand):
        """
        Define a binding between a Receiver object and an action.
        Implement Execute by invoking the corresponding operation(s) on
        Receiver.
        """

        def execute(self):
            logging.info("begins executing FindInventoryCommand")
            self._receiver.action()
            logging.info("after executing FindInventoryCommand")



class TargeCommand(LaunchCommand):
    """
    Define a binding between a Receiver object and an action.
    Implement Execute by invoking the corresponding operation(s) on
    Receiver.
    """

    def execute(self):
        logging.info("begins executing TargeCommand")
        self._receiver.action()
        logging.info("after  executing TargeCommand")

class CountryLimitCommand(LaunchCommand):
    """
    Define a binding between a Receiver object and an action.
    Implement Execute by invoking the corresponding operation(s) on
    Receiver.
    """

    def execute(self):
        logging.info("begins executing CountryLimitCommand")
        self._receiver.action()
        logging.info("after  executing CountryLimitCommand")

class  SqlExecutorCommand(LaunchCommand):
    """
    Define a binding between a Receiver object and an action.
    Implement Execute by invoking the corresponding operation(s) on
    Receiver.
    """

    def execute(self):
        logging.info("begins executing SqlExecutorCommand")
        self._receiver.action()
        logging.info("after  executing SqlExecutorCommand")

class GenerateLaunchReportCommand(LaunchCommand):
    """
    Define a binding between a Receiver object and an action.
    Implement Execute by invoking the corresponding operation(s) on
    Receiver.
    """

    def execute(self):
        self._receiver.action()

class EmailLaunchReportCommand(LaunchCommand):
    """
    Define a binding between a Receiver object and an action.
    Implement Execute by invoking the corresponding operation(s) on
    Receiver.
    """

    def execute(self):
        self._receiver.action()

