from launch_pipelines.application_config.application_config import application_config
from launch_pipelines.ul_3_launch_command import FindInventoryRceiver, Invoker, TargetRceiver, FindInventoryCommand, \
    TargeCommand, CountryLimitRceiver, CountryLimitCommand, SqlExcecutorRceiver, SqlExecutorCommand, \
    GenerateLaunchReportRceiver, GenerateLaunchReportCommand
from launch_pipelines.utils import LAUNCH_TYPES
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session

if __name__ == "__main__":

    spark_session = get_hive_spark_session()
    app_config = application_config(spark_session, LAUNCH_TYPES.IC)

    # client that is responsible for
    # executing  all commands
    command_invoker = Invoker()

    # find inventory
    find_inventory_receiver = FindInventoryRceiver(LAUNCH_TYPES.IC,"inventory_command")
    find_inventory_command = FindInventoryCommand(find_inventory_receiver)
    command_invoker.store_command(find_inventory_command)

    # create target machines
    target_receiver = TargetRceiver(LAUNCH_TYPES.IC, "target_command")
    target_command = TargeCommand(target_receiver)
    command_invoker.store_command(target_command)


    # country limit by product
    country_limit_receiver = CountryLimitRceiver("gocart_etl_stg.ic_launch",LAUNCH_TYPES.IC)
    country_limit_command = CountryLimitCommand(country_limit_receiver)
    command_invoker.store_command(country_limit_command)

    # execute SQL's
    sql_executor_receiver =  SqlExcecutorRceiver(LAUNCH_TYPES.IC)
    sql_executor_command = SqlExecutorCommand(sql_executor_receiver)
    command_invoker.store_command(sql_executor_command)

    # execute commands in the order added
    command_invoker.execute_commands()