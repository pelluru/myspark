#  once audit report verified manually
#  this job will be invoked