"""
This class loads all launch config
@TODO make this as Singleton
"""
from launch_pipelines.utils import data_files_root_paths

class LaunchConfig():
    def __init__(self,spark_session,launch_type):
        self._spark_session = spark_session
        self._launch_type = launch_type
        self._launch_type_path = "/launch_config/"+launch_type

    def get_sql_config(self):
        sql_execute_order_file_path = data_files_root_paths.LAUNCH_CONFIG_ROOT_PATH+self._launch_type_path+"/sqls/sql_execution_order.csv"
        return self._spark_session.read.csv(header=True,
                                                path=sql_execute_order_file_path)
