from launch_pipelines.application_config.application_config import application_config
from launch_pipelines.ul_6_unified_join import AdditionalColumn, UnifiedJoin
from pyspark.sql.functions import col
from launch_pipelines.utils.hive_spark_session_util import get_hive_spark_session

"""
Concrete Strategies implement the algorithm while following the base Strategy
interface. The interface makes them interchangeable in the Context.
Here we can switch between  HIVE and CSV source , rest of the code need not modify
"""

class CreateDataFramesFromHIVEStrategy():
    """
       Usually, the Context accepts a strategy through the constructor, but
       also provides a setter to change it at runtime.
       """

    def createDataFrames(self, launch_type, command_type) :

        spark_session = get_hive_spark_session()

        app_config = application_config(spark_session,launch_type)

        join_config_df = app_config.get_join_config()

        join_config_df1 = join_config_df.where(
            (col("launch_type") == launch_type) & (col("command_type") == command_type))
        join_config_df1.show()
        joins_list = []
        rows = join_config_df1.collect()

        for row in rows:
            row_dict = row.asDict()
            addional_columns_config_df = app_config.get_addional_columns_config()

            additional_column_rows = addional_columns_config_df.collect()
            additional_columns = []

            for additional_column_row in additional_column_rows:
                additional_column_dict = additional_column_row.asDict()
                additional_column = AdditionalColumn(
                    launch_type=additional_column_dict['launch_type'],
                    additional_column_name=additional_column_dict['additional_column_name'],
                    column_type=additional_column_dict['column_type'],
                    default_value=additional_column_dict['default_value']
                )

                additional_columns.append(additional_column)

            if row_dict['dedupe_columns'] == 'None':
                # no dedupe columns configured
                dedupe_columns = []
            else:
                dedupe_columns = row_dict['dedupe_columns'].split('&')

            if row_dict['sql_filter_conditions'] == 'None':
                # no filter conditions configured
                sql_filter_conditions = []
            else:
                sql_filter_conditions = row_dict['sql_filter_conditions'].split('&')

            unified_join = UnifiedJoin(config_record=row_dict,
                                       config_row_id=row_dict['id'],
                                       join_type=row_dict['join_type'],
                                       left_table=row_dict['left_table'],
                                       right_table=row_dict['right_table'],
                                       left_side_columns=row_dict['left_side_columns'].split('&'),
                                       right_side_columns=row_dict['right_side_columns'].split('&'),
                                       left_select_columns=row_dict['left_select_columns'].split('&'),
                                       right_select_columns=row_dict['right_select_columns'].split('&'),
                                       additional_default_columns=additional_columns,
                                       joined_result_table_name=row_dict['joined_result_table_name'],
                                       temp_table_result_flag=row_dict['temp_table_result_flag'],
                                       sql_filter_conditions=sql_filter_conditions,
                                       dedupe_flag=row_dict['dedupe_flag'],
                                       dedupe_columns=dedupe_columns

                                       )

            joins_list.append(unified_join)

        return joins_list