echo "started copying launch config"
hdfs dfs -put -f ./launch_config/ /user/gocuser/unified_launches
hdfs dfs -put -f ./application_config/ /user/gocuser/unified_launches
echo "after copying launch config"