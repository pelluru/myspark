Deployment Steps for gcs-to-bq-validation-framework Pipeline.

% make dev

python3 gcs-to-bq-validation-framework.py  --beam_project_id i-dss-ingest-dev --input gs://i-dss-ingest-dev-staging/pelluru/gcs-to-bq-validation-framework1/DAIAdServerInteraction_8264*20220522*.gz --bq_project_id i-dss-ingest-dev  --bq_audit_table_id i-dss-ingest-dev.gcs_to_bq_validations.gcs_to_bq_audit  --job_name gcs-to-bq-validation-framework-job --temp_location gs://i-dss-ingest-dev-staging/pelluru/dfstaging
