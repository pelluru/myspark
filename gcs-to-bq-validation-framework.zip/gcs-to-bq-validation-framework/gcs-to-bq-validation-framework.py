
"""A gcs-to-bq validation workflow."""

import argparse
import logging
from datetime import datetime

import apache_beam as beam
from apache_beam import Pipeline
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io import fileio, ReadFromText, WriteToText
from apache_beam.transforms.combiners import Count

from google.cloud import bigquery

# Read Records from BQ for a given day
BQ_QUERY = "SELECT filename, count(*) Row_Count FROM  {table_name} Where  day_dt between  {start_date} and {end_date}  and  REGEXP_EXTRACT(filename,{date_from_file_name}) ={date_from_file_name} Group by 1"

class GcsToBqValidationDoFn(beam.DoFn):

    def __init__(self, beam_project_id, bq_audit_table_id, bq_data_table_id , bq_data_query_start_date,bq_data_query_end_date,bq_data_query_date):
        self.beam_project_id = beam_project_id
        self.bq_audit_table_id = bq_audit_table_id
        self. bq_data_table_id = bq_data_table_id
        self.bq_data_query_start_date = bq_data_query_start_date
        self.bq_data_query_end_date = bq_data_query_end_date
        self.bq_data_query_date = bq_data_query_date


    def process(self,gcs_file_name_record_count):
        logging.info(gcs_file_name_record_count)
        gcs_bq_validation = GcsToBqValidation()
        bq_file_name_record_count = gcs_bq_validation.getBigQueryRecordCount(self.beam_project_id,self.bq_data_table_id,self.bq_data_query_start_date,self.bq_data_query_end_date,self.bq_data_query_date)

        logging.info("*************: Bq Records:"+str(len(bq_file_name_record_count)))
        logging.info(len(bq_file_name_record_count))
        bq_file_name_record_count.sort(reverse=True)

        logging.info("*************: GCS Records:"+str(len(gcs_file_name_record_count)))
        logging.info(len(gcs_file_name_record_count))
        gcs_file_name_record_count.sort(reverse=True)

        matches = (set(bq_file_name_record_count ) - set(gcs_file_name_record_count))

        if(len(matches)) ==0:
            gcs_bq_validation.insertFileRecords(gcs_file_name_record_count,bq_file_name_record_count,"SUCCESSFUL",self.beam_project_id,self.bq_audit_table_id,str(matches))
        else:
            gcs_bq_validation.insertFileRecords(gcs_file_name_record_count, bq_file_name_record_count, "FAILED",self.beam_project_id,self.bq_audit_table_id,str(matches))

        logging.info("Not matches count: set(gcs_file_name_record_count) - set(bq_file_name_record_count):"+str(len(matches)))
        logging.info("Not matches Set: set(gcs_file_name_record_count) - set(bq_file_name_record_count):" + str(matches))

        yield bq_file_name_record_count

class GcsToBqValidation:
    def insertFileRecords(self, gcs_filename_count_dict , bq_filename_count_dict, validation_status,beam_project_id,bq_audit_table_id, error):
            client = bigquery.Client(beam_project_id)
            audit_table = client.get_table(bq_audit_table_id)

            rows_to_insert = [ ("GDAI Logs", "Daily",validation_status,datetime.now().isoformat(),datetime.now().isoformat(), error,gcs_filename_count_dict , bq_filename_count_dict ) ]
            errors=client.insert_rows(audit_table, rows_to_insert)
            logging.info(errors)

    def  getBigQueryRecordCount(self,beam_project_id, bq_data_table_id,bq_data_query_start_date,bq_data_query_end_date,bq_data_query_date):
            client = bigquery.Client(beam_project_id)
            query_bq_records_count =  BQ_QUERY.format(table_name= bq_data_table_id,start_date=bq_data_query_start_date,end_date=bq_data_query_end_date,date_from_file_name=bq_data_query_date)
            logging.info("query_bq_records_count: Query:"+query_bq_records_count)
            query_job = client.query(query_bq_records_count)

            results = query_job.result()
            file_name_record_count_list = []

            for row in results:
              row_tuple = (row[0],row[1])
              file_name_record_count_list.append(row_tuple)

            return file_name_record_count_list

def run(**args):
    with Pipeline(options=args['pipeline_options']) as pipeline:
        readableFiles = (pipeline
                         | fileio.MatchFiles(args['input'])
                         | fileio.ReadMatches()
                         | "Shuffle read matches" >> beam.Reshuffle()
                         | beam.Map(lambda file: file.metadata.path)
                         | beam.io.ReadAllFromText(skip_header_lines=1, with_filename=True)
                         | Count.PerKey()
                         | beam.Map(lambda file: (file[0].split("/")[-1], file[1]))
                         | 'Combine' >> beam.combiners.ToList()
                         | beam.ParDo(GcsToBqValidationDoFn(args['beam_project_id'],args['bq_audit_table_id'],args['bq_data_table_id'],args['bq_data_query_start_date'],args['bq_data_query_end_date'],args['bq_data_query_date']))
                         )
def main():
    logging.getLogger().setLevel(logging.INFO)

    parser = argparse.ArgumentParser()
    parser.add_argument("--input",   help="The input GCP bucket path", required=True)
    parser.add_argument("--beam_project_id",      help="Beam Project ID", required=True)
    parser.add_argument("--bq_project_id",        help="BigQuery Project ID", required=True)
    parser.add_argument("--bq_audit_table_id",      help="Dataset.Table where audit data is stored", required=True )
    parser.add_argument("--bq_data_table_id",       help="projectId:Dataset.Table where audit data is stored", required=True)
    parser.add_argument("--bq_data_query_start_date", help="start date in yyyy-mm-dd format", required=True)
    parser.add_argument("--bq_data_query_end_date", help="end date in yyyy-mm-dd format", required=True)
    parser.add_argument("--bq_data_query_date", help="what date we are querying in yyyymmdd format", required=True)
    parser.add_argument("--job_name",             help="Beam Job Name", required=True )
    parser.add_argument("--machine_type",         help="Machine Type", default='n1-standard-1' )
    parser.add_argument("--temp_location",        help="Temp Location for Beam", required=True )
    parser.add_argument("--max_num_workers",      help="Max Workers Allowed", default=1 )
    parser.add_argument("--disk_size_gb",         help="Disk Size", default=30)
    known_args, pipeline_args = parser.parse_known_args()

    # Set `save_main_session` to True so DoFns can access globally imported modules.
    pipeline_options = PipelineOptions(
        pipeline_args, streaming=True, save_main_session=True,
        runner='DataflowRunner',
        project=known_args.beam_project_id,
        job_name=known_args.job_name,
        temp_location=known_args.temp_location,
        region='us-central1',
        machine_type=known_args.machine_type,
        max_num_workers=known_args.max_num_workers,
        disk_size_gb=known_args.disk_size_gb,
    )
    run(
        input=known_args.input,
        beam_project_id=known_args.beam_project_id,
        bq_project_id=known_args.bq_project_id,
        bq_audit_table_id=known_args.bq_audit_table_id,
        bq_data_table_id=known_args.bq_data_table_id,
        bq_data_query_start_date=known_args.bq_data_query_start_date,
        bq_data_query_end_date=known_args.bq_data_query_end_date,
        bq_data_query_date=known_args.bq_data_query_date,
        job_name=known_args.job_name,
        machine_type=known_args.machine_type,
        temp_location=known_args.temp_location,
        max_num_workers=known_args.max_num_workers,
        disk_size_gb=known_args.disk_size_gb,
        pipeline_options=pipeline_options,
    )
main()